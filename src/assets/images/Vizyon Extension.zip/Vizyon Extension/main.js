chrome.runtime.onMessage.addListener(function(req, sender, sendResponse) {
    const result = {
        continue: false,
        authData: req.message.authData
    }

    if (req.message.continue) {
        switch (req.message.authData.app) {
            case 'microsoftteams':
                return loginOffice365Step2(req.message.authData)
            case 'office365':
                return loginOffice365Step2(req.message.authData)
            case 'razkids':
                return loginRazkidsStep2(req.message.authData)
            case 'writingaz':
                return loginRazkidsStep2(req.message.authData)
            case 'vocabularyaz':
                return loginRazkidsStep2(req.message.authData)
            case 'scienceaz':
                return loginRazkidsStep2(req.message.authData)
        }
    }

    const app = req.message.authData.app

    if(app === 'vcloud'){
        result.continue = loginVCloud(req.message.authData)
    }

    if(app === 'highlightslibrary'){
        result.continue = loginHighlightsLibrary(req.message.authData)
    }

    if(app === 'rockalingua'){
        result.continue = loginRockalingua(req.message.authData)
    }

    if(app === 'linguaattack'){
        result.continue = loginLinguaAttack(req.message.authData)
    }

    if(app === 'myeduclass'){
        result.continue = loginMyEduClass(req.message.authData)
    }

    if(app === 'raunt'){
        result.continue = loginRaunt(req.message.authData)
    }

    if(app === 'myon'){
        result.continue = loginMyOn(req.message.authData)
    }

    if(app === 'pearsonenglishportal'){
        result.continue = loginPearsonEnglishPortal(req.message.authData)
    }

    if(app === 'brainmodify'){
        result.continue = loginBrainModify(req.message.authData)
    }

    if(app === 'compass'){
        result.continue = loginCompass(req.message.authData)
    }

    if (app === 'office365' || app === 'microsoftteams') {
        result.continue = loginOffice365Step1(req.message.authData)
    }

    if (app === 'morpa') {
        result.continue = loginMorpa(req.message.authData)
    }

    if (app === 'okuvaryumstudent' || app === 'okuvaryumteacher') {
        result.continue = loginOkuvaryum(req.message.authData)
    }

    if (app == 'razplus') {
        result.continue = loginRazplus(req.message.authData)
    }

    if (app === 'razkids') {
        result.continue = loginRazkidsStep1(req.message.authData)
    }

    if (app === 'writingaz') {
        result.continue = loginRazkidsStep1(req.message.authData)
    }

    if (app === 'vocabularyaz') {
        result.continue = loginRazkidsStep1(req.message.authData)
    }

    if (app === 'scienceaz') {
        result.continue = loginRazkidsStep1(req.message.authData)
    }

    // Other Apps

    // if (app === 'khanAcademy') {
    //     result.continue = loginKhanAcademy(req.message.authData)
    // }

    // if (app === 'udemy') {
    //     result.continue = loginUdemy(req.message.authData)
    // }

    // if (app === 'activelylearn') {
    //     result.continue = loginActivelyLearn(req.message.authData)
    // }

    // if (app === 'brainpop') {
    //     result.continue = loginBrainpop(req.message.authData)
    // }

    // if (app === 'eba') {
    //     result.continue = loginEBA(req.message.authData)
    // }

    // if (app === 'unlocklearning') {
    //     result.continue = loginUnlockLearning(req.message.authData)
    // }

    // if (app === 'k12') {
    //     result.continue = loginK12(req.message.authData)
    // }


    sendResponse(result)
});


// SCRIPTS

//  ************  Vizyon Okulları ************ //

// OFFICE STEP1
const loginOffice365Step1 = (authData) => {
    let otherAccountButton;
    let emailField;

    const waitOtherTile = setInterval(() => {
        setTimeout(() => {
            clearInterval(waitOtherTile)
        }, 5000);
        otherAccountButton = document.getElementById('otherTile')
        if (otherAccountButton) {
            otherAccountButton.click()
            clearInterval(waitOtherTile)
        }
    }, 200);

    const waitEmail = setInterval(() => {
        setTimeout(() => {
            clearInterval(waitEmail)
        }, 8000);
        emailField = document.getElementById('i0116')
        if (emailField) {
            emailField.value = authData.email
            emailField.blur()
            document.getElementById('idSIButton9').click()
            clearInterval(waitEmail)
        };
    }, 200);

    return true
}

// OFFICE STEP2
const loginOffice365Step2 = async(authData) => {
    let passwordField = await waitForItem('#i0118')
    if (passwordField) {
        passwordField.value = authData.password
        passwordField.blur()

        document.getElementById('idSIButton9').click()
    }
};

// RAZKIDS STEP1
const loginRazkidsStep1 = (authData) => {
    let teacherField = document.getElementById('username')
    let loginForm = document.getElementById('loginFormTeacherUsername')
    if (teacherField) {
        teacherField.setAttribute('value', authData.teacher)
    }
    if (loginForm) {
        loginForm.submit()
    }

    const waitForStudents = setInterval(() => {
        let students = document.getElementsByClassName('kidsLogin-name')

        if (students.length > 0) {
            let student_name = authData.user.toLocaleLowerCase('en-EN').split(' ').join('')
            student_name = convertTurkishCharacters(student_name)

            console.log(student_name)
            for (const student of students) {
                let name = student.innerHTML
                name = name.toLowerCase().split(' ').join('')

                if (name == student_name) {
                    student.click()
                    clearInterval(waitForStudents)
                    return
                }
            }
            alert('İsminiz listedeki kullanıcılardan herhangi biri ile eşleşmedi')
            clearInterval(waitForStudents)
        }
    }, 200);
    return true
};

// RAZKIDS STEP2
const loginRazkidsStep2 = (authData) => {
    const waitForPassword = setInterval(() => {
        let passwordField = document.getElementById('student-password')
        let loginForm = document.getElementById('accessForm')
        if (passwordField && loginForm) {
            passwordField.setAttribute('value', authData.password)
            loginForm.submit()
            clearInterval(waitForPassword)
        }
    }, 200);
    return false
}

// MORPA
const loginMorpa = async(authData) => {
    let usernameField = await waitForItem('#username')
    let passwordField = await waitForItem('#password')
    let loginForm = await waitForItem('#login_form')

    usernameField.setAttribute('value', authData.username)
    passwordField.setAttribute('value', authData.password)

    loginForm.submit()
}

// OKUVARYUM
const loginOkuvaryum = async(authData) => {
    let usernameField = await waitForItem('input[name="username"]')
    let passwordField = await waitForItem('input[name="password"]')

    usernameField.setAttribute('value', authData.username)
    passwordField.setAttribute('value', authData.password)

    document.forms[0].submit()

    return false
}

// VCLOUD 
const loginVCloud = async(authData) => {
    let usernameField = await waitForItem('#l_un')
    let passwordField = await waitForItem('#l_pw')
    let loginButton = await waitForItem('#login-button')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// HIGHLIGHTS LIBRARY 
const loginHighlightsLibrary = async(authData) => {
    let usernameField = await waitForItem('#id')
    let passwordField = await waitForItem('#pass')
    let loginButton = await waitForItem('#loginbtn')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// ROCKALINGUA
const loginRockalingua = async(authData) => {
    let usernameField = await waitForItem('#edit-name')
    let passwordField = await waitForItem('#edit-pass')
    let loginButton = await waitForItem('#edit-submit')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username || authData.email
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// LINGUA ATTACK
const loginLinguaAttack = async(authData) => {
    let usernameField = await waitForItem('#edit-name')
    let passwordField = await waitForItem('#edit-pass')
    let loginButton = await waitForItem('#edit-submit')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username || authData.email
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// MYEDUCLASS
const loginMyEduClass = async(authData) => {
    let usernameField = document.getElementsByTagName("input")[0]
    let passwordField = document.getElementsByTagName("input")[1]
    let loginButton = document.getElementsByTagName("button")[0]

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// RAUNT
const loginRaunt = async(authData) => {
    
    let tcknField = await waitForItem('#tckn')
    let passwordField = await waitForItem('#password')
    let loginButton = await waitForItem('#login-button')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    tcknField.value = authData.username
    tcknField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// MYON ENGLISH LIBRARY
const loginMyOn = async(authData) => {
    let schoolNameField = await waitForItem('input[name="building"]')
    let schoolName = document.getElementById('buildingText')
    let usernameField = document.getElementById('username_input')
    let passwordField = document.getElementById('password_input')
    let loginButton = document.getElementsByClassName('button -signin')[0]
    
    schoolNameField.value = "2339265"
    schoolName.value = "Vizyon Koleji Marina"
    usernameField.value = authData.username
    passwordField.value = authData.password

    loginButton.click()
}

// PEARSON ENGLISH PORTAL
const loginPearsonEnglishPortal = async(authData) => {
    
    let usernameField = await waitForItem('#idgen-pefInput-1')
    let passwordField = await waitForItem('#idgen-pefInput-2')
    let loginButton = document.getElementsByClassName('form-button pep-button--flat pep-button--default pep-button--primary pep-button')[0]

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// BRAIN MODIFY
const loginBrainModify = async(authData) => {
    
    let usernameField = await waitForItem('#txtKareKod')
    let loginButton = await waitForItem('#btnGiris')  

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    loginButton.click()
}

// COMPASS DIGITAL PLATFORM
const loginCompass = async(authData) => {
    let schoolNameField = await waitForItem('#j2schoolName')
    let usernameField = await waitForItem('#j2userName')
    let passwordField = await waitForItem('#acce55_pa55w0rd')
    let loginButton = await waitForItem('#singleSignIn')

    schoolNameField.value = "UES-ACADEMY"
    usernameField.value = authData.username
    passwordField.value = authData.password

    loginButton.click()
}

// OTHER APPS

// UDEMY
const loginUdemy = async(authData) => {
    let emailField = await waitForItem('input[name="email"]')
    emailField.value = authData.email || authData.username

    let passwordField = await waitForItem('#id_password')
    passwordField.value = authData.password

    let loginButton = await waitForItem('#submit-id-submit')

    loginButton.click()
}

// KHAN ACADEMY
const loginKhanAcademy = async(authData) => {
    let usernameField = $("#uid-identity-text-field-0-email-or-username")
    let passwordField = $('#uid-identity-text-field-1-password')
    let loginButton = $('[data-test-id="log-in-submit-button"]')

    await waitFor(500)

    usernameField.focus()
    usernameField.val(authData.username || authData.email)
    usernameField.change()

    usernameField.attr("value", authData.username || authData.email);
    usernameField.replaceWith(usernameField.clone());

    passwordField.focus()
    passwordField.val(authData.password)
    passwordField.change()

    passwordField.attr("value", authData.password);
    passwordField.replaceWith(passwordField.clone());

    loginButton.click()
}

// BRAIN POP
const loginBrainpop = async(authData) => {
    let openLoginForm = await waitForItem('#login_button')
    openLoginForm.childNodes[0].click()

    let usernameField = await waitForItem('#login')
    let passwordField = await waitForItem('#password')
    let loginButton = await waitForItem('#btnLogin')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// ACTIVELY LEARN
const loginActivelyLearn = async(authData) => {
    let usernameField = await waitForItem('#username')
    let passwordField = await waitForItem('#password')
    let loginButton = await waitForItem('button[type="submit"]')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// EBA
const loginEBA = async(authData) => {

    let tcknField = await waitForItem('#tckn')
    let passwordField = await waitForItem('#password')

    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    tcknField.value = authData.username
    tcknField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    document.forms[0].submit()
}

// UNLOCK LEARNING
const loginUnlockLearning = async(authData) => {
    let usernameField = await waitForItem('#gigya-loginID-33136461830823732')
    let passwordField = await waitForItem('#gigya-password-272446220556026')
    let loginButton = await waitForItem('input[value="Log in"]')

    usernameField = $('#gigya-loginID-33136461830823732')
    passwordField = $('#gigya-password-272446220556026')
    loginButton = $('input[value="Log in"]')

    loginButton.click(function() {
        usernameField.val(authData.username)
        passwordField.val(authData.password)
    })

    loginButton.click()
}

// K12  
const loginK12 = async(authData) => {
    let usernameField = await waitForItem('#TbUsername')
    let passwordField = await waitForItem('#TbPassword')
    let loginButton = await waitForItem('#loginButton')


    var event = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    usernameField.value = authData.username
    usernameField.dispatchEvent(event);

    var event2 = new Event('input', {
        'bubbles': true,
        'cancelable': true
    });

    passwordField.value = authData.password
    passwordField.dispatchEvent(event2);

    loginButton.click()
}

// RAZ PLUS

const loginRazplus = async(authData) => {
    let memberLogin = await waitForItem('span[class="btn"]')
    memberLogin.click()

    let usernameField = await waitForItem('#username')
    let passwordField = await waitForItem('#password')
    let loginButton = await waitForItem('#submit')
    usernameField.value = authData.username
    passwordField.value = authData.password
    loginButton.click()

};



// CUSTOM FUNCTIONS

const waitForItem = (selector) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            reject('Cannot load element')
        }, 8000);
        let el = document.querySelector(selector);
        if (el) { resolve(el); }
        new MutationObserver((mutationRecords, observer) => {
                // Query for elements matching the specified selector
                Array.from(document.querySelectorAll(selector)).forEach((element) => {
                    resolve(element);
                    //Once we have resolved we don't need the observer anymore.
                    observer.disconnect();
                });
            })
            .observe(document.documentElement, {
                childList: true,
                subtree: true
            });
    });
}


const waitFor = (milis) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve()
        }, milis);
    })
}

const convertTurkishCharacters = (text) => {
    return text.replace('Ğ', 'g')
        .replace('Ü', 'u')
        .replace('Ş', 's')
        .replace('I', 'i')
        .replace('İ', 'i')
        .replace('Ö', 'o')
        .replace('Ç', 'c')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ı', 'i')
        .replace('ö', 'o')
        .replace('ç', 'c');
}