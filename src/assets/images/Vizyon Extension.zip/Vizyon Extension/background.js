const path_name = '/api/v1/gelisim-sso/redirect'

let isExtensionOn = true

const listenForPages = function(tabID, changeInfo) {
    if (!isExtensionOn) {
        return
    }
    if (changeInfo.url) {
        const url = new URL(changeInfo.url)
        if (url.pathname === path_name) {

            const token = url.searchParams.get('token')
            const authData = jwt_decode(token)
            if (!authData) {
                return console.log('platform and user info should be given')
            }
            chrome.tabs.update(tabID, { url: authData.url },
                function(tab) {
                    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                        if (info.status === 'complete' && tabId === tab.id) {
                            chrome.tabs.onUpdated.removeListener(listener);
                            chrome.tabs.sendMessage(tabID, {
                                message: {
                                    authData
                                }
                            }, (res) => {
                                console.log(res)
                                if (res.continue) {
                                    chrome.tabs.onUpdated.addListener((tabId, info) => {
                                        if (info.status === 'complete' && tabId === tab.id) {
                                            chrome.tabs.onUpdated.removeListener(listener);
                                            chrome.tabs.sendMessage(tabID, {
                                                message: {
                                                    authData,
                                                    continue: res.continue
                                                }
                                            })
                                        }
                                    })
                                }
                            })
                        }
                    });
                });
        }
    }
}


chrome.tabs.onUpdated.addListener(listenForPages)


chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.cmd == "setOnOffState") {
            isExtensionOn = request.data.value;
        }

        if (request.cmd == "getOnOffState") {
            sendResponse(isExtensionOn);
        }
    });