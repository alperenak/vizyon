window.onload = function() {
    const toggle = document.getElementById('toggle')
    chrome.extension.sendMessage({ cmd: 'getOnOffState' }, function(response) {
        toggle.checked = response
    })

    toggle.onchange = function(e) {
        chrome.extension.sendMessage({ cmd: 'setOnOffState', data: { value: toggle.checked } })
    }
}