###Vizy Auto-Login

Bu uzantı Gelişim Okulları öğrencileri için belli platformlarda otomatik giriş işlemini yapması için oluşturulmuştur. Eğer Gelişim Okullarının dijital kampüs platformunu kullanıyorsanız, bu eklentiyi yükleyerek uygulamalara erişim sağlayabilirsiniz.

This extension helps Gelisim Okullari students to login some specific websites with credentials that provided by the school. You can download this extension to use automatic login feature of digital campus